package com.example.user.airsharing;

/**
 * Created by surin on 2017. 5. 29..
 */

public class DeviceData {
    String device_id1;
    String device_id2;
    String device_id3;
    String device_id4;
    String device_id5;
    String userid;


    public String getDevice_id2() {
        return device_id2;
    }

    public void setDevice_id2(String device_id2) {
        this.device_id2 = device_id2;
    }

    public String getDevice_id3() {
        return device_id3;
    }

    public void setDevice_id3(String device_id3) {
        this.device_id3 = device_id3;
    }

    public String getDevice_id4() {
        return device_id4;
    }

    public void setDevice_id4(String device_id4) {
        this.device_id4 = device_id4;
    }

    public String getDevice_id5() {
        return device_id5;
    }

    public void setDevice_id5(String device_id5) {
        this.device_id5 = device_id5;
    }

    public String getDevice_id1() {
        return device_id1;
    }

    public void setDevice_id1(String device_id1) {
        this.device_id1 = device_id1;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

}

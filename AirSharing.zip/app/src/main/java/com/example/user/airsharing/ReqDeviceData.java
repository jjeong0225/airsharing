package com.example.user.airsharing;

/**
 * Created by user on 2017-06-11.
 */

public class ReqDeviceData {
    String device_id;

    public String getDevice_id() {
        return device_id;
    }

    public void setDevice_id(String device_id) {
        this.device_id = device_id;
    }
}
